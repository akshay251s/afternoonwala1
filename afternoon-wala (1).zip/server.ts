import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization pattern for GoogleGenAI to prevent crashing at boot if API key is not yet set
let aiInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY environment variable is not configured in Secrets.");
    }
    aiInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

// In-Memory Enquiry Store seeded with 2 realistic enquiries for demonstration
const enquiries = [
  {
    id: "enq_1",
    name: "Rohan Patil",
    phone: "+91 94222 12345",
    eventDate: "2026-11-20",
    eventType: "wedding",
    estimatedBudget: "₹75,000 - ₹1,00,000",
    balloonColors: ["Peach", "Muted Gold", "Chrome Rose Gold"],
    themeNotes: "Traditional wedding stage with a modern pastel balloon halo and cold pyro entry fog.",
    lowFogRequired: true,
    stageDecorationScale: "luxury",
    submittedAt: new Date(Date.now() - 36000000).toISOString()
  },
  {
    id: "enq_2",
    name: "Sneha Chaudhari",
    phone: "+91 98905 54321",
    eventDate: "2026-08-15",
    eventType: "birthday",
    estimatedBudget: "₹25,000 - ₹35,000",
    balloonColors: ["Pastels", "Matte White", "Chrome Gold"],
    themeNotes: "First birthday celebration of baby boy. Organic arch plus name marquee lights.",
    lowFogRequired: false,
    stageDecorationScale: "grand",
    submittedAt: new Date(Date.now() - 7200000).toISOString()
  }
];

// --- API Endpoints ---

// Live Server Health Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Afternoon Wala backend operating successfully" });
});

// Fetch enquiries
app.get("/api/enquiries", (req, res) => {
  res.json(enquiries);
});

// Post new enquiry
app.post("/api/enquiry", (req, res) => {
  const {
    name,
    phone,
    eventDate,
    eventType,
    estimatedBudget,
    balloonColors,
    themeNotes,
    lowFogRequired,
    stageDecorationScale
  } = req.body;

  if (!name || !phone || !eventType) {
    return res.status(400).json({ error: "Missing required fields (Name, Phone, and Event Type are required)" });
  }

  const newEnquiry = {
    id: `enq_${Date.now()}`,
    name,
    phone,
    eventDate: eventDate || "TBD",
    eventType,
    estimatedBudget: estimatedBudget || "Calculating...",
    balloonColors: balloonColors || [],
    themeNotes: themeNotes || "No specific themes requested yet.",
    lowFogRequired: !!lowFogRequired,
    stageDecorationScale: stageDecorationScale || "standard",
    submittedAt: new Date().toISOString()
  };

  enquiries.push(newEnquiry);
  res.status(201).json({ success: true, enquiry: newEnquiry });
});

// Chatbot powered by Gemini Flash
app.post("/api/chat", async (req, res) => {
  const { message, history, context } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message is required." });
  }

  try {
    const ai = getGeminiClient();

    const systemInstruction = 
      "You are 'Afternoon Wala AI Assistant', the helpful, professional virtual manager for Afternoon Wala event planning and luxury decorators based in Jalgaon City, Maharashtra.\n\n" +
      "Afternoon Wala is highly reputable in Jalgaon City. We specialize in:\n" +
      "- Custom luxury wedding stage setups, beautiful mandaps and backdrops.\n" +
      "- Modern organic balloon arrangements using elite matte colors, chrome/metallic luster, and pastels. We strictly avoid cheap-looking shiny primary colors and messy wiring.\n" +
      "- Unbelievable special entrance productions like heavy dry-ice low fog (the 'cloud-walking' effect) and LED cold pyro elements.\n" +
      "- High-end birthday theme stages, naming ceremonies, anniversaries, and corporate events.\n\n" +
      "YOUR DESIGN STYLE & PALETTE:\n" +
      "- Warm Golds, premium chromes and metals, elegant dusty pastels, and pristine clean whites.\n" +
      "- Avoid cheap designs, blurry spacing, and messy setups.\n\n" +
      "PRICING GUIDES (For Jalgaon City Area):\n" +
      "- Standard setups (gorgeous backdrops + organic balloon garlands): ₹8,000 - ₹15,000\n" +
      "- Grand celebration stages (large arches, metallic accents, custom lettering, moderate floral work): ₹20,000 - ₹45,000\n" +
      "- Elite Luxury Stages (epic mandap draping, massive premium flowers mixed with organic pastel balloons, heavy dry-ice fog, premium stage furniture, and LED spotlights): Starting from ₹55,000 up to ₹2,50,000+\n" +
      "- Heavy dry-ice low fog standalone hire: ₹5,000 - ₹8,000 per entry session\n\n" +
      "ROLE & RESPONSIBILITY:\n" +
      "- Inspire users to plan their perfect events. Suggest elegant color combos (e.g., Lavender & Chrome Gold, Pastel Blue & Sage Green & Rose Gold).\n" +
      "- Collect context gracefully (ask if they want a dry-ice fog cloud effect for the couple entry, or scale of their stage).\n" +
      "- Always write answers in a cheerful, prompt-focused, polite, and highly structured manner.\n" +
      "- Avoid jargon. Support regional details for Jalgaon City contexts (like setups at prominent Jalgaon halls, lawns, or home courtyards if relevant).\n" +
      "- Keep summaries clear. Respond as a true hospitality consultant.";

    // Convert history into acceptable parts structure
    const formattedContents = [];
    if (history && Array.isArray(history)) {
      for (const h of history) {
        formattedContents.push({
          role: h.role,
          parts: [{ text: h.text }]
        });
      }
    }

    // Add current user prompt
    let userPromptText = message;
    if (context && Object.keys(context).length > 0) {
      userPromptText += `\n\n[Client-provided Context: Event Type: ${context.eventType || "N/A"}, Preferred scale: ${context.stageDecorationScale || "N/A"}, Balloon colors of interest: ${(context.balloonColors || []).join(", ") || "N/A"}, Wants low fog cloud effect? ${context.lowFogRequired ? 'Yes' : 'No'}]`;
    }

    formattedContents.push({
      role: "user",
      parts: [{ text: userPromptText }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedContents,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      },
    });

    const responseText = response.text || "I apologize, but I couldn't generate a recommendation. Please let me know how I can help with your event in Jalgaon!";
    
    // Provide dynamic custom suggestions
    let suggestions = [
      "Show me Wedding Stage Packages",
      "Explain the Low-Fog 'Cloud Walking' Effect",
      "I want a Custom Pastel Birthday Arch",
      "Get a detailed quote estimate"
    ];

    if (message.toLowerCase().includes("wedding") || message.toLowerCase().includes("mandap")) {
      suggestions = [
        "What is the starting price for Wedding stages?",
        "Tell me about flower-balloon hybrid themes",
        "Add dry-ice fog to my wedding entry",
        "View past Jalgaon wedding setups"
      ];
    } else if (message.toLowerCase().includes("birthday") || message.toLowerCase().includes("balloon")) {
      suggestions = [
        "What colors look best for a 1st birthday?",
        "Premium chrome vs standard balloons",
        "Tell me about neon-light name backdrops",
        "Calculate birthday stage estimate"
      ];
    } else if (message.toLowerCase().includes("fog") || message.toLowerCase().includes("cloud") || message.toLowerCase().includes("effect")) {
      suggestions = [
        "Is the dry-ice fog safe for indoor halls in Jalgaon?",
        "How long does the low fog effect last?",
        "Can we combine cold pyro with dry ice?",
        "Price check for smoke & fog machine"
      ];
    }

    res.json({
      answer: responseText,
      suggestions: suggestions
    });

  } catch (error: any) {
    console.error("Gemini assistant error:", error);
    res.status(500).json({ 
      error: "Could not initialize AI discussion. If you are a developer, please check if GEMINI_API_KEY is properly loaded.",
      details: error.message || error
    });
  }
});

// Integrate Vite configuration for React SPAs
const distPath = path.join(process.cwd(), "dist");

if (process.env.NODE_ENV !== "production") {
  import("vite").then(async (viteModule) => {
    const vite = await viteModule.createServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  });
} else {
  app.use(express.static(distPath));
  app.get("*", (req, res) => {
    res.sendFile(path.join(distPath, "index.html"));
  });
}

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Afternoon Wala server successfully running on http://0.0.0.0:${PORT}`);
});
