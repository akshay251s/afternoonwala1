export interface ServiceItem {
  id: string;
  title: string;
  category: "wedding" | "birthday" | "special_effects" | "custom_corporate";
  description: string;
  priceRange: string;
  imageUrl: string;
  features: string[];
}

export interface EstimationOption {
  id: string;
  name: string;
  basePrice: number;
  description: string;
}

export interface CelebrationPackage {
  id: string;
  name: string;
  price: number;
  description: string;
  includes: string[];
  vibe: string;
}

export interface ReviewItem {
  id: string;
  user: string;
  date: string;
  rating: number;
  content: string;
  eventType: string;
}

export interface Message {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: string;
  suggestions?: string[];
}

export interface EnquiryForm {
  name: string;
  phone: string;
  eventDate: string;
  eventType: string;
  estimatedBudget: string;
  balloonColors: string[];
  themeNotes: string;
  lowFogRequired: boolean;
  stageDecorationScale: "standard" | "grand" | "luxury";
}

export interface ChatRequest {
  message: string;
  history?: { role: "user" | "model"; text: string }[];
  context?: Partial<EnquiryForm>;
}

export interface ChatResponse {
  answer: string;
  suggestions?: string[];
  estimatedCostRange?: { min: number; max: number };
}
