import React, { useState, useEffect, useRef } from "react";
import {
  Sparkles,
  Calendar,
  DollarSign,
  CheckCircle2,
  MapPin,
  Phone,
  Mail,
  FileText,
  Cloud,
  MessageSquare,
  Plus,
  Trash2,
  Users,
  ShieldCheck,
  Award,
  Clock,
  ArrowRight,
  ChevronRight,
  ChevronDown
} from "lucide-react";
import { ServiceItem, CelebrationPackage, ReviewItem, Message, EnquiryForm } from "./types";

// Predefined static data following Afternoon Wala's authentic palette and offerings
const SERVICES_DATA: ServiceItem[] = [
  {
    id: "wed_stage",
    title: "Luxury Wedding Stage & Traditional Mandap",
    category: "wedding",
    description: "Breathtaking premium stages in Jalgaon featuring rich white drapes, majestic suspensions of fresh marigolds or pastel roses, mixed with bespoke gold geometric frame arches.",
    priceRange: "₹55,000 - ₹1,80,000",
    imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=80",
    features: [
      "Custom double-layered grand drapery",
      "Traditional & contemporary mandap layouts",
      "Premium stage couch & luxury seating sets",
      "Concealed LED wash spotlighting",
      "Fresh floral ceiling hangings"
    ]
  },
  {
    id: "premium_bday",
    title: "Organic Custom Birthday Stages",
    category: "birthday",
    description: "Massive, modern organic balloon arches avoiding cheap shiny material. We blend custom double-stuffed pastel peach, sage, and premium gold chrome drapes with high-end neon name signage.",
    priceRange: "₹15,000 - ₹45,000",
    imageUrl: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=800&q=80",
    features: [
      "No cheap balloons - custom double-stuffed matte pastels",
      "High-shine metallic chrome balloon detailing",
      "Premium cake display tables with velvet plinths",
      "Custom hanging neon signs (integrated dimmer)",
      "Zero exposed wires or visible brackets"
    ]
  },
  {
    id: "cloud_fog",
    title: "Mystical Dry-Ice Staging & Fog Clouds",
    category: "special_effects",
    description: "Our signature heavy dry-ice fog effect producing high-density low fog that hugs the floor like a cloud. Perfect for couple entries or grand stage presentations without setting off fire alarms.",
    priceRange: "₹6,000 - ₹12,000",
    imageUrl: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=800&q=80",
    features: [
      "Continuous thick cloud cover (hugs the floor perfectly)",
      "Non-toxic, odorless, completely safe for children & elder guests",
      "Dual state heaters for immediate high output flow",
      "Coordinated color uplighting effects",
      "On-site professional machine controller included"
    ]
  }
];

const PACKAGES_DATA: CelebrationPackage[] = [
  {
    id: "pkg_classic",
    name: "Classic Pastels & Lights Backdrop",
    price: 12500,
    description: "Perfect for naming ceremonies, simple birthdays, or intimate house warming events inside Jalgaon.",
    includes: [
      "8x8ft Premium fabric or circular wire grid backdrop",
      "Organic balloon garland (choice of up to 3 pastel colors)",
      "LED warm fairy lights & 2 spot floodlights",
      "Custom printed birthday/occasion circular boarding",
      "Perfect backdrop tidy cabling cover"
    ],
    vibe: "Warm, cozy, and highly polished"
  },
  {
    id: "pkg_grand",
    name: "Aura Grand Theme Stage",
    price: 28500,
    description: "A showstopper high-density setup featuring gorgeous premium details suitable for grand corporate events or luxurious halls.",
    includes: [
      "12x10ft Multi-layered wooden geometrical backdrops",
      "Premium chrome gold & double-layered dusty rose balloon arches",
      "Integrated custom neon glow lettering sign",
      "3 elegant velvet cake plinths with decorative cake stands",
      "Fresh floral crown topper mix",
      "Dual stage base spotlighting"
    ],
    vibe: "Vibrant, celebrated, and deeply memorable"
  },
  {
    id: "pkg_royal",
    name: "The Royal Cloud Stage Suite",
    price: 65000,
    description: "Our ultimate signature stage masterpiece combining luxury wedding florals, premium balloons, and spectacular dry-ice cloud effects.",
    includes: [
      "Grand 20ft luxury stage setup with professional drapes",
      "Combination floral arrangements & organic soft-gold balloon swags",
      "Premium luxury stage couch set (choice of royal white or velvet gold)",
      "Heavy dry-ice low-lying fog machine session with 2 couple entrance runs",
      "LED warm washing light installation",
      "On-site supervisor and decoration team throughout the event"
    ],
    vibe: "Splendid, elite, and absolutely magical"
  }
];

const REVIEWS_DATA: ReviewItem[] = [
  {
    id: "rev_1",
    user: "Harshal Jain",
    date: "May 12, 2026",
    rating: 5,
    content: "Afternoon Wala managed my sister's wedding reception stage. The low fog effect was an absolute dream—it felt like they were dancing on actual clouds! Everyone in Jalgaon was talking about the premium pastel balloon colors. Exceptional work!",
    eventType: "Wedding Reception"
  },
  {
    id: "rev_2",
    user: "Mayuri Patil",
    date: "April 28, 2026",
    rating: 5,
    content: "Absolutely spectacular 1st birthday decoration! I was so worried about wires and messy stands because children were running around, but their team double-taped and concealed everything. Highly recommend their matte peach and rose gold organic designs.",
    eventType: "1st Birthday"
  },
  {
    id: "rev_3",
    user: "Dipak Chaudhari",
    date: "March 15, 2026",
    rating: 5,
    content: "We hired Afternoon Wala for a corporate celebration stage. Professional behavior, timely setup, and reasonable pricing compared to other decorators in Jalgaon. The neon sign was a huge hit!",
    eventType: "Anniversary & Naming Ceremony"
  }
];

const AVAILABLE_BALLOON_COLORS = [
  "Dusty Rose", "Chrome Gold", "Chrome Silver", "Matte Peach", 
  "Sage Green", "Lavender Soft", "Teal Blue Pastel", "Pristine White", "Muted Bronze"
];

export default function App() {
  // Navigation active tab
  const [activeTab, setActiveTab] = useState<"showcase" | "estimator" | "enquiry">("showcase");

  // Selection states for Cost Estimator
  const [eventType, setEventType] = useState<string>("wedding");
  const [stageScale, setStageScale] = useState<"standard" | "grand" | "luxury">("grand");
  const [balloonBases, setBalloonBases] = useState<string[]>(["Dusty Rose", "Chrome Gold", "Pristine White"]);
  const [includeLowFog, setIncludeLowFog] = useState<boolean>(true);
  const [addonCouch, setAddonCouch] = useState<boolean>(true);
  const [addonNeon, setAddonNeon] = useState<boolean>(false);
  const [addonSpotlights, setAddonSpotlights] = useState<boolean>(true);
  const [customNotes, setCustomNotes] = useState<string>("");

  // Enquiry Form State
  const [enquiryForm, setEnquiryForm] = useState<EnquiryForm>({
    name: "",
    phone: "",
    eventDate: "",
    eventType: "wedding",
    estimatedBudget: "",
    balloonColors: ["Dusty Rose", "Chrome Gold", "Pristine White"],
    themeNotes: "",
    lowFogRequired: true,
    stageDecorationScale: "grand"
  });

  // Submitted Enquiries Live Log
  const [submittedEnquiries, setSubmittedEnquiries] = useState<any[]>([]);
  const [loadingEnquiries, setLoadingEnquiries] = useState<boolean>(true);
  const [submittingEnquiry, setSubmittingEnquiry] = useState<boolean>(false);
  const [enquirySuccessModal, setEnquirySuccessModal] = useState<boolean>(false);
  const [registeredEnquiryId, setRegisteredEnquiryId] = useState<string>("");

  // Chatbot State
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "msg_init",
      role: "model",
      text: "Namaste! Welcome to Afternoon Wala. I am your custom Event Planning AI Assistant. I specialize in mapping out gorgeous color schemes, designing staging dimensions, and outlining budget calculations for Jalgaon events. Ask me anything about our premium pastel organic balloon setups, traditional mandaps, or the dry-ice low-lying fog effect!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestions: [
        "What is the starting price for Wedding stages?",
        "Explain the Low-Fog 'Cloud Walking' Effect",
        "What colors look best for a 1st birthday?",
        "Help me match Pastel Lavender balloon options"
      ]
    }
  ]);
  const [userInput, setUserInput] = useState<string>("");
  const [chatLoading, setChatLoading] = useState<boolean>(false);

  // Synchronize Estimator with Enquiry form inputs
  useEffect(() => {
    // Dynamically estimate budget string
    const minCalculated = calculateEstimatedCost(eventType, stageScale, includeLowFog, addonCouch, addonNeon, addonSpotlights).min;
    const maxCalculated = calculateEstimatedCost(eventType, stageScale, includeLowFog, addonCouch, addonNeon, addonSpotlights).max;
    
    setEnquiryForm(prev => ({
      ...prev,
      eventType: eventType,
      stageDecorationScale: stageScale,
      balloonColors: balloonBases,
      lowFogRequired: includeLowFog,
      estimatedBudget: `₹${minCalculated.toLocaleString("en-IN")} - ₹${maxCalculated.toLocaleString("en-IN")}`,
      themeNotes: customNotes || `Premium custom setup. Neon sign: ${addonNeon ? 'Yes' : 'No'}. Couch rental: ${addonCouch ? 'Yes' : 'No'}.`
    }));
  }, [eventType, stageScale, balloonBases, includeLowFog, addonCouch, addonNeon, addonSpotlights, customNotes]);

  // Fetch submitted enquiries from server on mount
  useEffect(() => {
    fetchEnquiries();
  }, []);

  const fetchEnquiries = async () => {
    try {
      setLoadingEnquiries(true);
      const res = await fetch("/api/enquiries");
      if (res.ok) {
        const data = await res.json();
        setSubmittedEnquiries(data);
      }
    } catch (e) {
      console.error("Could not fetch enquiries", e);
    } finally {
      setLoadingEnquiries(false);
    }
  };

  // Helper calculating real-time dynamic costs
  function calculateEstimatedCost(
    type: string,
    scale: "standard" | "grand" | "luxury",
    fog: boolean,
    couch: boolean,
    neon: boolean,
    lights: boolean
  ) {
    let baseMin = 10000;
    let baseMax = 15000;

    if (type === "wedding") {
      baseMin = 45000;
      baseMax = 65000;
    } else if (type === "birthday") {
      baseMin = 12000;
      baseMax = 18000;
    } else if (type === "special_effects") {
      baseMin = 8000;
      baseMax = 12000;
    }

    // Scale multipliers
    let multiplierMin = 1.0;
    let multiplierMax = 1.0;

    if (scale === "standard") {
      multiplierMin = 0.8;
      multiplierMax = 0.85;
    } else if (scale === "grand") {
      multiplierMin = 1.1;
      multiplierMax = 1.25;
    } else if (scale === "luxury") {
      multiplierMin = 1.7;
      multiplierMax = 2.1;
    }

    let min = Math.round(baseMin * multiplierMin);
    let max = Math.round(baseMax * multiplierMax);

    // Staging Addons flat fees
    if (fog) {
      min += 5500;
      max += 7000;
    }
    if (couch) {
      min += 4500;
      max += 5500;
    }
    if (neon) {
      min += 2500;
      max += 3500;
    }
    if (lights) {
      min += 3000;
      max += 4500;
    }

    return { min, max };
  }

  // Cost estimates for display
  const currentEstimate = calculateEstimatedCost(eventType, stageScale, includeLowFog, addonCouch, addonNeon, addonSpotlights);

  // Toggle balloon color items
  const handleToggleColor = (color: string) => {
    if (balloonBases.includes(color)) {
      if (balloonBases.length > 1) {
        setBalloonBases(balloonBases.filter(c => c !== color));
      }
    } else {
      setBalloonBases([...balloonBases, color]);
    }
  };

  // Apply visual package settings automatically
  const handleApplyPackage = (pkg: CelebrationPackage) => {
    setCustomNotes(`Royal applied package: '${pkg.name}'`);
    if (pkg.id === "pkg_classic") {
      setEventType("birthday");
      setStageScale("standard");
      setIncludeLowFog(false);
      setAddonCouch(false);
      setAddonNeon(false);
      setAddonSpotlights(true);
      setBalloonBases(["Teal Blue Pastel", "Matte Peach", "Pristine White"]);
    } else if (pkg.id === "pkg_grand") {
      setEventType("birthday");
      setStageScale("grand");
      setIncludeLowFog(false);
      setAddonCouch(true);
      setAddonNeon(true);
      setAddonSpotlights(true);
      setBalloonBases(["Chrome Gold", "Dusty Rose", "Pristine White"]);
    } else if (pkg.id === "pkg_royal") {
      setEventType("wedding");
      setStageScale("luxury");
      setIncludeLowFog(true);
      setAddonCouch(true);
      setAddonNeon(true);
      setAddonSpotlights(true);
      setBalloonBases(["Chrome Gold", "Matte Peach", "Lavender Soft"]);
    }
    // Switch to estimator view
    setActiveTab("estimator");
    // Scroll to form with smooth animations
    const element = document.getElementById("estimator-board");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  // Form submit handler
  const handleEnquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!enquiryForm.name || !enquiryForm.phone) {
      alert("Please provide at least a name and contact phone number.");
      return;
    }

    try {
      setSubmittingEnquiry(true);
      const res = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(enquiryForm)
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setRegisteredEnquiryId(data.enquiry.id);
          setEnquirySuccessModal(true);
          // Refresh list
          fetchEnquiries();
          // Reset custom fields but retain static config
          setEnquiryForm(prev => ({
            ...prev,
            name: "",
            phone: "",
            eventDate: "",
          }));
        }
      }
    } catch (err) {
      console.error("Enquiry submission failed", err);
    } finally {
      setSubmittingEnquiry(false);
    }
  };

  // Handle chatbot send
  const handleChatSend = async (messageText: string) => {
    if (!messageText.trim()) return;

    const userMsg: Message = {
      id: `user_${Date.now()}`,
      role: "user",
      text: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setUserInput("");
    setChatLoading(true);

    // Prepare contextual payload
    const contextPayload = {
      eventType,
      stageDecorationScale: stageScale,
      balloonColors: balloonBases,
      lowFogRequired: includeLowFog
    };

    // Keep last 6 histories to handle token state beautifully
    const chatHistory = messages.slice(-6).map(m => ({
      role: m.role,
      text: m.text
    }));

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: messageText,
          history: chatHistory,
          context: contextPayload
        })
      });

      if (res.ok) {
        const data = await res.json();
        const modelMsg: Message = {
          id: `model_${Date.now()}`,
          role: "model",
          text: data.answer,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestions: data.suggestions || []
        };
        setMessages(prev => [...prev, modelMsg]);
      } else {
        const errData = await res.json();
        throw new Error(errData.error || "Failed API roundtrip");
      }
    } catch (e: any) {
      console.error("Chat error", e);
      const errorMsg: Message = {
        id: `err_${Date.now()}`,
        role: "model",
        text: `Consultation Service Note: I couldn't connect directly with the decor coordinator. Please make sure you have declared your GEMINI_API_KEY inside the Secrets panel. For immediate planning, standard package starting from ₹8,000 can be processed using our dynamic estimator above!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestions: ["Explain wedding packages", "Starting cost details"]
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setChatLoading(false);
      // Auto scroll conversational panel
      setTimeout(() => {
        const chatBox = document.getElementById("chat-conversation-container");
        if (chatBox) {
          chatBox.scrollTop = chatBox.scrollHeight;
        }
      }, 100);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50 text-slate-800 font-sans flex flex-col antialiased">
      
      {/* Top Banner Message representing trust factors & location */}
      <div id="top-announce-rail" className="bg-amber-950 text-white py-2 px-4 text-xs font-outfit tracking-wide flex justify-between items-center sm:px-8 border-b border-amber-900/30">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
          <span>Now Booking Premium Weddings & Birthdays for Winter 2026 across Jalgaon City!</span>
        </div>
        <div className="hidden md:flex items-center gap-4 text-amber-200">
          <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> Jalgaon, MH</span>
          <span className="flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5" /> Tidy Clean Cabling Guarantee</span>
        </div>
      </div>

      {/* Main Luxury Header */}
      <header className="bg-white/95 backdrop-blur-md border-b border-neutral-100 shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Brand Logo Identity */}
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <div className="bg-amber-100 p-1.5 rounded-lg border border-amber-200/50">
                <Sparkles className="w-6 h-6 text-amber-600" />
              </div>
              <h1 className="text-2xl font-serif font-semibold tracking-tight text-slate-900">
                Afternoon <span className="text-amber-600 font-outfit font-extrabold italic">Wala</span>
              </h1>
            </div>
            <span className="text-[10px] font-mono tracking-wider text-slate-500 uppercase ml-9">
              Luxury Decorator • Jalgaon City
            </span>
          </div>

          {/* Desktop Tab Navigation */}
          <nav className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab("showcase")}
              className={`px-4 py-2 rounded-lg text-sm font-outfit tracking-wide transition-colors ${
                activeTab === "showcase"
                  ? "bg-amber-500 text-white shadow-sm font-semibold"
                  : "text-slate-600 hover:bg-neutral-100 hover:text-slate-900"
              }`}
            >
              Gallery & Packages
            </button>
            <button
              onClick={() => setActiveTab("estimator")}
              className={`px-4 py-2 rounded-lg text-sm font-outfit tracking-wide transition-colors flex items-center gap-1.5 ${
                activeTab === "estimator"
                  ? "bg-amber-500 text-white shadow-sm font-semibold"
                  : "text-slate-600 hover:bg-neutral-100 hover:text-slate-900"
              }`}
            >
              Cost Estimator <span className="bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200 text-[10px] px-1.5 py-0.5 rounded-full uppercase scale-90">Live</span>
            </button>
            <button
              onClick={() => setActiveTab("enquiry")}
              className={`px-4 py-2 rounded-lg text-sm font-outfit tracking-wide transition-colors ${
                activeTab === "enquiry"
                  ? "bg-amber-500 text-white shadow-sm font-semibold"
                  : "text-slate-600 hover:bg-neutral-100 hover:text-slate-900"
              }`}
            >
              Submit Enquiry
            </button>
          </nav>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-grow">
        
        {/* HERO SECTION CONTAINER - SHOWCASE VIEW ONLY */}
        {activeTab === "showcase" && (
          <div className="relative overflow-hidden bg-neutral-900 py-24 sm:py-32">
            
            {/* Ambient Background Glows */}
            <div className="absolute inset-0 z-0 opacity-40">
              <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl anim-pulse-subtle"></div>
              <div className="absolute bottom-12 left-1/3 w-[500px] h-[500px] bg-amber-600/10 rounded-full blur-3xl anim-pulse-subtle" style={{ animationDelay: '3s' }}></div>
            </div>

            {/* Background Hero Image */}
            <div className="absolute inset-0 z-0">
              <img
                src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1600&q=80"
                alt="Luxury Wedding Mandap Background"
                className="w-full h-full object-cover opacity-25 object-center scale-105 transition-transform duration-1000"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-900/90 to-neutral-900/60"></div>
            </div>

            <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/20 text-amber-300 rounded-full text-xs font-outfit tracking-wide mb-6 border border-amber-500/30">
                <Sparkles className="w-3.5 h-3.5" /> High-End Event Designs
              </div>

              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-semibold text-white tracking-tight leading-tight max-w-4xl mx-auto">
                Where Celebrations Meet <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-200 font-serif italic text-5xl sm:text-6xl lg:text-7xl">
                  Magical Staging Elegance
                </span>
              </h2>

              <p className="mt-6 text-lg text-neutral-300 max-w-2xl mx-auto font-outfit">
                Bespoke event planning, architectural floral configurations, custom pastel balloon setups, and our signature low-lying dry-ice cloud effects tailored for weddings and grand birthdays in Jalgaon City.
              </p>

              {/* Action Buttons */}
              <div className="mt-10 flex flex-wrap gap-4 justify-center">
                <button
                  onClick={() => setActiveTab("estimator")}
                  className="bg-amber-500 hover:bg-amber-600 text-neutral-950 font-outfit font-semibold px-8 py-4 rounded-xl shadow-lg transition-transform hover:-translate-y-0.5 flex items-center gap-2 cursor-pointer"
                >
                  Configure Custom Design estimate <ArrowRight className="w-4 h-4" />
                </button>
                <a
                  href="#premium-packages"
                  className="bg-white/10 hover:bg-white/15 text-white font-outfit font-semibold px-8 py-4 rounded-xl shadow-md transition-colors border border-white/20 flex items-center gap-1"
                >
                  Browse Packages
                </a>
              </div>

              {/* Value Propositions - Avoiding AI slop, showcasing professional trades/quality */}
              <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
                <div className="bg-white/5 backdrop-blur-sm p-4 rounded-xl border border-white/10">
                  <div className="text-amber-300 font-outfit font-bold text-lg mb-1 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" /> Premium Materials
                  </div>
                  <p className="text-xs text-neutral-400">Strictly thick latex double-stuffed pastel & lustrous chrome balloon sets.</p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm p-4 rounded-xl border border-white/10">
                  <div className="text-amber-300 font-outfit font-bold text-lg mb-1 flex items-center gap-1.5">
                    <Cloud className="w-4 h-4" /> Low-Fog Masters
                  </div>
                  <p className="text-xs text-neutral-400">True dry-ice heaters producing cold, floor-hugging mist that doesn't smell or rise.</p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm p-4 rounded-xl border border-white/10">
                  <div className="text-amber-300 font-outfit font-bold text-lg mb-1 flex items-center gap-1.5">
                    <Award className="w-4 h-4" /> Perfect Aesthetics
                  </div>
                  <p className="text-xs text-neutral-400">Zero exposed extension cables or visible tape backings. Tidy, high-end presentation.</p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm p-4 rounded-xl border border-white/10">
                  <div className="text-amber-300 font-outfit font-bold text-lg mb-1 flex items-center gap-1.5">
                    <Clock className="w-4 h-4" /> Flawless Setup
                  </div>
                  <p className="text-xs text-neutral-400">Punctual onsite team with fully redundant stage lighting ready before the doors open.</p>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* PAGE BODY WRAPPER */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          
          {/* TAB 1: MAIN SHOWCASE (GALLERY, PACKAGES, TESTIMONIALS) */}
          {activeTab === "showcase" && (
            <div className="space-y-16">
              
              {/* SECTION: MAIN SERVICES (W/ PHOTO CARDS & ACTION BUTTONS) */}
              <section>
                <div className="text-center max-w-3xl mx-auto mb-12">
                  <h3 className="text-3xl font-serif text-slate-900 font-bold">Signature Event Decor Pillars</h3>
                  <p className="text-slate-600 mt-2 font-outfit">
                    Every piece is crafted by our design architects with flawless attention to spacing, color balance, and neatness. Select any to customize in our Live Estimator!
                  </p>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                  {SERVICES_DATA.map((service) => (
                    <div key={service.id} className="bg-white rounded-2xl border border-neutral-100 shadow-sm overflow-hidden hover:shadow-md transition-shadow flex flex-col">
                      <div className="h-64 relative overflow-hidden group">
                        <img
                          src={service.imageUrl}
                          alt={service.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm shadow px-3 py-1 rounded-full text-xs font-mono font-bold text-amber-700">
                          {service.priceRange}
                        </div>
                      </div>
                      <div className="p-6 flex-grow flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] font-mono tracking-widest text-amber-600 uppercase block mb-1">
                            {service.category.replace("_", " ")} service
                          </span>
                          <h4 className="text-lg font-outfit font-bold text-slate-900 mb-2">{service.title}</h4>
                          <p className="text-sm text-slate-600 mb-4">{service.description}</p>
                          
                          <div className="space-y-2 mb-6">
                            {service.features.map((feat, idx) => (
                              <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                                <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                                <span>{feat}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            if (service.id === "wed_stage") {
                              setEventType("wedding");
                              setStageScale("luxury");
                              setIncludeLowFog(true);
                            } else if (service.id === "premium_bday") {
                              setEventType("birthday");
                              setStageScale("grand");
                            } else if (service.id === "cloud_fog") {
                              setEventType("special_effects");
                              setIncludeLowFog(true);
                            }
                            setActiveTab("estimator");
                          }}
                          className="w-full bg-neutral-900 hover:bg-neutral-800 text-white font-outfit font-medium text-xs py-3 rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          Load Setup into Estimator <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* SECTION: PREMIUM PACKAGES (W/ DETAILED CHECKLISTS) */}
              <section id="premium-packages" className="bg-warm-beige/30 p-8 sm:p-12 border border-gold/20">
                <div className="text-center max-w-3xl mx-auto mb-12">
                  <span className="text-xs font-bold tracking-[0.2em] uppercase text-gold">Curated Theme Blueprints</span>
                  <h3 className="text-3xl font-serif text-slate-900 font-bold mt-1">Ready-to-Deploy Ceremonial Packages</h3>
                  <p className="text-slate-600 mt-2 font-outfit text-sm">
                    Avoid the hassle of individual rentals. We have pre-integrated coordinates to ensure flawless, color-synced setups. Click to adapt instantly.
                  </p>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                  {PACKAGES_DATA.map((pkg) => (
                    <div key={pkg.id} className="bg-white border border-gray-100 shadow-sm p-6 flex flex-col justify-between hover:border-gold/40 hover:shadow-md transition-all">
                      <div>
                        {pkg.id === "pkg_royal" && (
                          <div className="bg-gold text-white text-[9px] uppercase font-mono font-bold tracking-widest px-2.5 py-1 inline-block mb-3">
                            Most Luxurious
                          </div>
                        )}
                        <h4 className="text-xl font-serif font-bold text-slate-900 mb-1">{pkg.name}</h4>
                        <div className="text-slate-500 italic text-xs mb-4 font-outfit">{pkg.vibe}</div>
                        
                        <div className="flex items-baseline gap-1.5 mb-5 border-b border-slate-100 pb-4">
                          <span className="text-3xl font-outfit font-extrabold text-gold">₹{pkg.price.toLocaleString("en-IN")}</span>
                          <span className="text-xs text-slate-400 font-mono">*Flat Rate</span>
                        </div>

                        <p className="text-xs text-slate-600 mb-5 leading-relaxed">{pkg.description}</p>

                        <div className="space-y-3 mb-6">
                          <div className="text-xs font-bold text-slate-900 uppercase tracking-wider">Includes:</div>
                          {pkg.includes.map((inc, i) => (
                            <div key={i} className="flex gap-2 text-xs text-slate-600">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                              <span>{inc}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={() => handleApplyPackage(pkg)}
                        className={`w-full py-3 rounded-none font-outfit font-semibold text-xs tracking-wide uppercase transition-colors cursor-pointer ${
                          pkg.id === "pkg_royal"
                            ? "bg-gold hover:bg-gold-hover text-white"
                            : "bg-slate-100 hover:bg-slate-200 text-slate-800"
                        }`}
                      >
                        Choose & Customize Package
                      </button>
                    </div>
                  ))}
                </div>
              </section>

              {/* CLIENT TESTIMONIALS */}
              <section>
                <div className="text-center max-w-2xl mx-auto mb-10">
                  <h3 className="text-2xl font-serif font-bold text-slate-900">Loved by Families Across Jalgaon</h3>
                  <p className="text-sm text-slate-500 mt-1">Read reviews from hosts at top Jalgaon halls and private home celebrations.</p>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  {REVIEWS_DATA.map((rev) => (
                    <div key={rev.id} className="bg-white p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
                      <p className="text-sm text-slate-600 italic leading-relaxed">"{rev.content}"</p>
                      
                      <div className="mt-6 border-t border-slate-100 pt-4 flex justify-between items-center">
                        <div>
                          <div className="text-xs font-bold font-outfit text-slate-900">{rev.user}</div>
                          <div className="text-[10px] text-gold font-mono font-bold uppercase tracking-wider">{rev.eventType}</div>
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">{rev.date}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* GEOGRAPHIC SCOPE */}
              <section className="bg-slate-950 text-white p-8 sm:p-12 relative overflow-hidden border border-gold/10">
                <div className="absolute inset-0 opacity-10">
                  <div className="absolute top-0 right-0 w-80 h-80 bg-gold rounded-full blur-2xl"></div>
                </div>
                
                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
                  <div className="max-w-xl text-left">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-gold/20 text-gold rounded-none text-xs font-outfit tracking-wider uppercase mb-4 border border-gold/30">
                      <MapPin className="w-3.5 h-3.5" /> Jalgaon City Coverage
                    </div>
                    <h4 className="text-2xl sm:text-3xl font-serif font-bold">Serving All Local Venues & lawns</h4>
                    <p className="text-sm text-slate-300 mt-3 leading-relaxed font-outfit">
                      We routinely deliver, secure, and dismantle decorations at major local venues in Jalgaon City: including Patidar Bhavan, Saffron, K.C. Park Lawns, Royal Palace, or right inside your private housing society courtyard or home veranda.
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab("enquiry")}
                    className="bg-gold hover:bg-gold-hover text-white font-outfit font-bold px-6 py-3.5 rounded-none uppercase text-xs tracking-wider transition-colors shrink-0 cursor-pointer"
                  >
                    Check Date Availability
                  </button>
                </div>
              </section>

            </div>
          )}

          {/* TAB 2: LIVE COST ESTIMATOR & IA ASSISTANT */}
          {activeTab === "estimator" && (
            <div className="space-y-12">
              
              <div id="estimator-board" className="grid lg:grid-cols-12 gap-8 items-start">
                
                {/* COLUMN 1: INTERACTIVE CALCULATOR (lg:col-span-7) */}
                <div className="lg:col-span-7 space-y-6">
                  
                  {/* BASE CONFIG */}
                  <div className="bg-white p-6 border border-slate-100 shadow-sm">
                    <h3 className="text-lg font-outfit font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <span className="bg-gold/10 text-gold px-2 py-0.5 text-sm font-mono font-bold">01</span>
                      Choose Your Celebration Base
                    </h3>

                    {/* EVENT TYPE CHOICE */}
                    <div className="mb-6">
                      <label className="text-[10px] tracking-wider font-bold text-slate-400 block mb-2 uppercase">Occasion Category</label>
                      <div className="grid grid-cols-3 gap-3">
                        <button
                          onClick={() => setEventType("wedding")}
                          className={`p-3 border transition-all flex flex-col items-center gap-1.5 cursor-pointer ${
                            eventType === "wedding"
                              ? "border-gold bg-warm-beige/35 text-slate-900 font-bold shadow-xs"
                              : "border-neutral-200 hover:bg-neutral-50 text-slate-600"
                          }`}
                        >
                          <Award className="w-4 h-4 text-gold" />
                          <span className="text-xs font-outfit uppercase tracking-wider">Wedding / Mandap</span>
                        </button>
                        <button
                          onClick={() => setEventType("birthday")}
                          className={`p-3 border transition-all flex flex-col items-center gap-1.5 cursor-pointer ${
                            eventType === "birthday"
                              ? "border-gold bg-warm-beige/35 text-slate-900 font-bold shadow-xs"
                              : "border-neutral-200 hover:bg-neutral-50 text-slate-600"
                          }`}
                        >
                          <Sparkles className="w-4 h-4 text-gold" />
                          <span className="text-xs font-outfit uppercase tracking-wider">Birthday Arch</span>
                        </button>
                        <button
                          onClick={() => setEventType("special_effects")}
                          className={`p-3 border transition-all flex flex-col items-center gap-1.5 cursor-pointer ${
                            eventType === "special_effects"
                              ? "border-gold bg-warm-beige/35 text-slate-900 font-bold shadow-xs"
                              : "border-neutral-200 hover:bg-neutral-50 text-slate-600"
                          }`}
                        >
                          <Cloud className="w-4 h-4 text-gold" />
                          <span className="text-xs font-outfit uppercase tracking-wider">Cloud & Staging</span>
                        </button>
                      </div>
                    </div>

                    {/* SCALE CHOICE */}
                    <div>
                      <label className="text-[10px] tracking-wider font-bold text-slate-400 block mb-2 uppercase">Decoration scale & complexity</label>
                      <div className="grid grid-cols-3 gap-3">
                        <button
                          onClick={() => setStageScale("standard")}
                          className={`p-3 border transition-all cursor-pointer ${
                            stageScale === "standard"
                              ? "border-gold bg-warm-beige/35 text-slate-900 font-bold"
                              : "border-neutral-200 hover:bg-neutral-50 text-slate-600"
                          }`}
                        >
                          <div className="text-xs font-outfit uppercase tracking-wider">Standard Backdrop</div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">8ft width</div>
                        </button>
                        <button
                          onClick={() => setStageScale("grand")}
                          className={`p-3 border transition-all cursor-pointer ${
                            stageScale === "grand"
                              ? "border-gold bg-warm-beige/35 text-slate-900 font-bold"
                              : "border-neutral-200 hover:bg-neutral-50 text-slate-600"
                          }`}
                        >
                          <div className="text-xs font-outfit uppercase tracking-wider">Grand Celebration</div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">12ft height</div>
                        </button>
                        <button
                          onClick={() => setStageScale("luxury")}
                          className={`p-3 border transition-all cursor-pointer ${
                            stageScale === "luxury"
                              ? "border-gold bg-warm-beige/35 text-slate-900 font-bold"
                              : "border-neutral-200 hover:bg-neutral-50 text-slate-600"
                          }`}
                        >
                          <div className="text-xs font-outfit uppercase tracking-wider">Elite Luxury Staging</div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">20ft full-length</div>
                        </button>
                      </div>
                    </div>

                  </div>

                  {/* COLORS & PALETTES DESIGN (Double-stuffed latex promise) */}
                  <div className="bg-white p-6 border border-slate-100 shadow-sm">
                    <h3 className="text-lg font-outfit font-bold text-slate-900 mb-1 flex items-center gap-2">
                      <span className="bg-gold/10 text-gold px-2 py-0.5 text-sm font-mono font-bold">02</span>
                      Curate Your Color Palette
                    </h3>
                    <p className="text-xs text-slate-500 mb-4 ml-8">We avoid transparent shiny plastic look. Choose coordinates from our premium palette:</p>

                    <div className="flex flex-wrap gap-2 mb-4 ml-8">
                      {AVAILABLE_BALLOON_COLORS.map((color) => {
                        const isSelected = balloonBases.includes(color);
                        return (
                          <button
                            key={color}
                            onClick={() => handleToggleColor(color)}
                            className={`px-3 py-1.5 rounded-none text-xs font-outfit transition-colors flex items-center gap-1.5 border cursor-pointer ${
                              isSelected
                                ? "bg-gold text-white border-gold font-semibold"
                                : "bg-neutral-50 hover:bg-neutral-100 text-slate-700 border-neutral-200"
                            }`}
                          >
                            <span className={`w-2 h-2 rounded-full ${
                              color === "Dusty Rose" ? "bg-pink-400" :
                              color === "Chrome Gold" ? "bg-gold shadow-xs" :
                              color === "Chrome Silver" ? "bg-slate-300 shadow-xs" :
                              color === "Matte Peach" ? "bg-orange-200" :
                              color === "Sage Green" ? "bg-emerald-300" :
                              color === "Lavender Soft" ? "bg-purple-300" :
                              color === "Teal Blue Pastel" ? "bg-cyan-200" :
                              color === "Pristine White" ? "bg-slate-100 border border-slate-300" : "bg-yellow-800"
                            }`}></span>
                            {color}
                          </button>
                        );
                      })}
                    </div>
                    <div className="text-[10px] text-zinc-600 bg-warm-beige/35 p-2.5 ml-8 border border-gold/15">
                      <strong>Design Tip:</strong> For high-end luxury events, combine 2 soft pastels (like Matte Peach & Lavender Soft) with 1 accent metal tone (Chrome Gold) for unparalleled elegance!
                    </div>
                  </div>

                  {/* OPTIONAL STAGING ADDONS */}
                  <div className="bg-white p-6 border border-slate-100 shadow-sm">
                    <h3 className="text-lg font-outfit font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <span className="bg-gold/10 text-gold px-2 py-0.5 text-sm font-mono font-bold">03</span>
                      Incorporate Premium Staging Add-ons
                    </h3>

                    <div className="space-y-4">
                      
                      {/* LOW FOG EFFECT */}
                      <label className="flex items-center justify-between p-3.5 border border-slate-150 hover:bg-neutral-50 transition-colors cursor-pointer block">
                        <div className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            checked={includeLowFog}
                            onChange={(e) => setIncludeLowFog(e.target.checked)}
                            className="w-4 z-10 h-4 accent-gold"
                          />
                          <div>
                            <span className="text-sm font-bold text-slate-900 block flex items-center gap-1.5">
                              Magical Heavy Low-Fog Cloud Entrance
                              <span className="bg-gold/10 text-gold text-[9px] px-1.5 py-0.5 uppercase font-mono font-bold">Signature</span>
                            </span>
                            <span className="text-xs text-slate-500 block">Dry-ice low smoke hugging the floor perfectly. No fog machine smell.</span>
                          </div>
                        </div>
                        <span className="text-xs font-mono font-bold text-gold shrink-0">+₹6,000</span>
                      </label>

                      {/* PREMIUM COUCH */}
                      <label className="flex items-center justify-between p-3.5 border border-slate-150 hover:bg-neutral-50 transition-colors cursor-pointer block">
                        <div className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            checked={addonCouch}
                            onChange={(e) => setAddonCouch(e.target.checked)}
                            className="w-4 h-4 accent-gold"
                          />
                          <div>
                            <span className="text-sm font-bold text-slate-900 block">Premium Stage Couch Set</span>
                            <span className="text-xs text-slate-500 block">Choose elegant royal white or gold-trim buttoned back couches.</span>
                          </div>
                        </div>
                        <span className="text-xs font-mono font-bold text-gold shrink-0">+₹5,000</span>
                      </label>

                      {/* GLOWING NEON */}
                      <label className="flex items-center justify-between p-3.5 border border-slate-150 hover:bg-neutral-50 transition-colors cursor-pointer block">
                        <div className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            checked={addonNeon}
                            onChange={(e) => setAddonNeon(e.target.checked)}
                            className="w-4 h-4 accent-gold"
                          />
                          <div>
                            <span className="text-sm font-bold text-slate-900 block">Custom Warm Neon Glow Lettering Sign</span>
                            <span className="text-xs text-slate-500 block">E.g., "Better Together", "Happy Birthday", "Oh Baby", custom names.</span>
                          </div>
                        </div>
                        <span className="text-xs font-mono font-bold text-gold shrink-0">+₹3,000</span>
                      </label>

                      {/* SPOTLIGHTS */}
                      <label className="flex items-center justify-between p-3.5 border border-slate-150 hover:bg-neutral-50 transition-colors cursor-pointer block">
                        <div className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            checked={addonSpotlights}
                            onChange={(e) => setAddonSpotlights(e.target.checked)}
                            className="w-4 h-4 accent-gold"
                          />
                          <div>
                            <span className="text-sm font-bold text-slate-900 block">Additional LED Wash Uplighting & Focus Sets</span>
                            <span className="text-xs text-slate-500 block">Dramatically silhouettes the balloon geometry and drapes.</span>
                          </div>
                        </div>
                        <span className="text-xs font-mono font-bold text-gold shrink-0">+₹4,000</span>
                      </label>

                    </div>
                  </div>

                  {/* EXTRA DESIGN NOTES */}
                  <div className="bg-white p-6 border border-slate-100 shadow-sm">
                    <label className="text-xs font-bold text-slate-400 block mb-2 uppercase tracking-wider">Custom Design Notes for our decorators</label>
                    <textarea
                      value={customNotes}
                      onChange={(e) => setCustomNotes(e.target.value)}
                      placeholder="E.g., Wedding at Saffron Hall, Jalgaon, wanted baby pink & peach flower combinations, heavy cloud fog entry for the couple on entrance track..."
                      rows={3}
                      className="w-full bg-neutral-50 p-3 border border-neutral-200 text-sm focus:bg-white focus:ring-1 focus:ring-gold focus:outline-none"
                    ></textarea>
                  </div>

                </div>

                {/* COLUMN 2: ESTIMATION SLATE & REAL AI CHAT (lg:col-span-5) */}
                <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-24">
                  
                  {/* REAL-TIME COST BREAKDOWN */}
                  <div className="bg-slate-950 text-white p-6 border border-gold/15 shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-5">
                      <DollarSign className="w-24 h-24 text-gold" />
                    </div>

                    <div className="relative z-10 text-left">
                      <div className="text-[10px] font-mono uppercase text-gold font-bold tracking-widest mb-1">Live Estimate Calculated</div>
                      <h4 className="text-3xl font-serif font-extrabold text-[#ffffff]">
                        ₹{currentEstimate.min.toLocaleString("en-IN")} - ₹{currentEstimate.max.toLocaleString("en-IN")}
                      </h4>
                      <p className="text-[10px] text-slate-400 mt-1 italic">
                        *Estimates tailored for Jalgaon venues. Dismantling and cleanup logistics are fully covered in price.
                      </p>

                      {/* Summary Tags */}
                      <div className="mt-5 space-y-2.5 border-t border-slate-800 pt-4 text-xs">
                        <div className="flex justify-between">
                          <span className="text-slate-400">Event Base:</span>
                          <span className="capitalize font-bold text-white">{eventType.replace("_", " ")}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Stage Scale:</span>
                          <span className="capitalize font-bold text-white">{stageScale} Backdrop</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Colors:</span>
                          <span className="font-bold text-white truncate max-w-[200px]">{balloonBases.join(", ")}</span>
                        </div>
                        
                        {/* Staging add-ons listed */}
                        <div className="flex flex-wrap gap-1.5 pt-3 border-t border-slate-800">
                          {includeLowFog && <span className="bg-gold/10 text-gold font-mono text-[9px] px-2.5 py-0.5 border border-gold/20">Cloud Fog Incl.</span>}
                          {addonCouch && <span className="bg-gold/10 text-gold font-mono text-[9px] px-2.5 py-0.5 border border-gold/20">Premium Couch Incl.</span>}
                          {addonNeon && <span className="bg-gold/10 text-gold font-mono text-[9px] px-2.5 py-0.5 border border-gold/20">Neon Sign Incl.</span>}
                          {addonSpotlights && <span className="bg-gold/10 text-gold font-mono text-[9px] px-2.5 py-0.5 border border-gold/20">Spotlights Incl.</span>}
                        </div>
                      </div>

                      <div className="mt-6 flex gap-2">
                        <button
                          onClick={() => setActiveTab("enquiry")}
                          className="w-full bg-gold hover:bg-gold-hover text-white text-xs font-outfit font-bold py-3.5 px-4 rounded-none uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          Adopt & Submit Enquiry Form <FileText className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* AI STAGE CONSULTANT CHAT BOX */}
                  <div className="bg-white border border-slate-200 shadow-md overflow-hidden flex flex-col h-[520px]">
                    
                    {/* Header */}
                    <div className="bg-slate-950 border-b border-gold/10 text-white p-4 flex items-center gap-3">
                      <div className="bg-gold p-2 text-white shrink-0">
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <div className="text-left">
                        <h4 className="text-sm font-outfit font-bold flex items-center gap-1.5">
                          Afternoon Wala AI Consultant
                          <span className="bg-gold text-white font-mono font-bold text-[8px] px-1.5 py-0.5">V2.5</span>
                        </h4>
                        <p className="text-[10px] text-slate-400">Smart theme assistant & palette planner</p>
                      </div>
                    </div>

                    {/* Chat Messages */}
                    <div id="chat-conversation-container" className="flex-grow p-4 overflow-y-auto space-y-4 bg-slate-50 text-xs">
                      
                      {messages.map((msg) => (
                        <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                          <div className={`max-w-[85%] p-3.5 shadow-xs text-left ${
                            msg.role === "user"
                              ? "bg-gold text-white rounded-none"
                              : "bg-white text-slate-800 border border-slate-100 rounded-none leading-relaxed"
                          }`}>
                            <div className="whitespace-pre-wrap">{msg.text}</div>
                            
                            {/* suggestions chips inside AI balloons */}
                            {msg.suggestions && msg.suggestions.length > 0 && (
                              <div className="mt-3.5 flex flex-wrap gap-1.5 border-t border-slate-100 pt-2.5">
                                {msg.suggestions.map((s, idx) => (
                                  <button
                                    key={idx}
                                    onClick={() => handleChatSend(s)}
                                    className="bg-neutral-50 hover:bg-gold/5 text-gold border border-gold/20 text-[10px] px-2.5 py-1 transition-colors font-outfit cursor-pointer"
                                  >
                                    {s}
                                  </button>
                                ))}
                              </div>
                            )}

                            <span className="block text-[8px] text-right mt-1 opacity-70 font-mono">
                              {msg.timestamp}
                            </span>
                          </div>
                        </div>
                      ))}

                      {chatLoading && (
                        <div className="flex justify-start">
                          <div className="bg-white border border-slate-100 text-slate-500 rounded-none p-3 max-w-[85%] text-left">
                            <div className="flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce"></span>
                              <span className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                              <span className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce" style={{ animationDelay: '0.4s' }}></span>
                              <span className="text-[10px] font-outfit italic ml-1">Curating design palette...</span>
                            </div>
                          </div>
                        </div>
                      )}

                    </div>

                    {/* Footer Input */}
                    <div className="p-3 border-t border-slate-200 bg-white flex gap-2">
                      <input
                        type="text"
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") handleChatSend(userInput);
                        }}
                        placeholder="Ask about themes, color pairs, custom stages..."
                        className="flex-grow bg-neutral-100 py-2.5 px-3 rounded-none text-xs focus:bg-white focus:ring-1 focus:ring-gold focus:outline-none"
                        disabled={chatLoading}
                      />
                      <button
                        onClick={() => handleChatSend(userInput)}
                        className="bg-gold hover:bg-gold-hover text-white px-5 rounded-none text-xs font-bold font-outfit uppercase tracking-wider transition-colors shrink-0 disabled:opacity-50 cursor-pointer"
                        disabled={chatLoading || !userInput.trim()}
                      >
                        Send
                      </button>
                    </div>

                  </div>

                </div>

              </div>

            </div>
          )}

          {/* TAB 3: SUBMIT ENQUIRY FORM / ACTIVE REGISTRY */}
          {activeTab === "enquiry" && (
            <div className="space-y-12">
              
              <div className="grid lg:grid-cols-12 gap-8 items-start">
                
                {/* COLUMN 1: NEW BOOKING REQUEST FORM (lg:col-span-7) */}
                <form onSubmit={handleEnquirySubmit} className="lg:col-span-7 bg-white p-6 sm:p-8 border border-slate-100 shadow-sm space-y-6">
                  
                  <div className="text-left">
                    <h3 className="text-xl font-serif font-bold text-slate-900">Afternoon Wala • Booking enquiry</h3>
                    <p className="text-xs text-slate-500 mt-1 pb-4 border-b border-slate-100">
                      Our coordinator will check date availability & contact you within 2-4 hours. Pricing estimates below is dynamically imported from your active settings.
                    </p>
                  </div>

                  {/* 3-Column Fields */}
                  <div className="grid md:grid-cols-3 gap-4 text-left">
                    
                    <div>
                      <label className="text-xs font-bold text-slate-600 block mb-1">Your Full Name *</label>
                      <input
                        type="text"
                        required
                        value={enquiryForm.name}
                        onChange={(e) => setEnquiryForm({ ...enquiryForm, name: e.target.value })}
                        placeholder="E.g., Ajay Patil"
                        className="w-full bg-neutral-50 p-3 rounded-none border border-neutral-200 text-sm focus:bg-white focus:ring-1 focus:ring-gold focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-600 block mb-1">Phone Number (Indian format +91) *</label>
                      <input
                        type="tel"
                        required
                        value={enquiryForm.phone}
                        onChange={(e) => setEnquiryForm({ ...enquiryForm, phone: e.target.value })}
                        placeholder="E.g., +91 94222 XXXXX"
                        className="w-full bg-neutral-50 p-3 rounded-none border border-neutral-200 text-sm focus:bg-white focus:ring-1 focus:ring-gold focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-600 block mb-1">Anticipated Event Date</label>
                      <input
                        type="date"
                        value={enquiryForm.eventDate}
                        onChange={(e) => setEnquiryForm({ ...enquiryForm, eventDate: e.target.value })}
                        className="w-full bg-neutral-50 p-3 rounded-none border border-neutral-200 text-sm focus:bg-white focus:ring-1 focus:ring-gold focus:outline-none text-slate-700"
                      />
                    </div>

                  </div>

                  {/* Summary of Configuration derived in Estimator */}
                  <div className="bg-warm-beige/35 p-4 border border-gold/15 text-xs space-y-4 text-left">
                    <div className="font-bold uppercase tracking-widest text-[9px] text-gold">Estimator Settings Loaded:</div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div>
                        <span className="text-slate-400 block text-[10px]">Event Category</span>
                        <strong className="capitalize text-slate-800">{enquiryForm.eventType}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Staging Scale</span>
                        <strong className="capitalize text-slate-800">{enquiryForm.stageDecorationScale} Backdrop</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Low Fog Included?</span>
                        <strong className="text-slate-800">{enquiryForm.lowFogRequired ? 'Yes' : 'No'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Calculated Budget</span>
                        <strong className="text-gold">{enquiryForm.estimatedBudget}</strong>
                      </div>
                    </div>

                    <div>
                      <span className="text-slate-400 block mb-1 text-[10px]">Colors Selected:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {enquiryForm.balloonColors.map((c, i) => (
                          <span key={i} className="bg-white px-2 py-0.5 rounded-none border border-neutral-200 text-[10px]">
                            {c}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-400 italic pt-1 border-t border-slate-100">
                      Need to update these? Use the "Cost Estimator" tab first.
                    </div>
                  </div>

                  {/* THEME NOTES */}
                  <div className="text-left">
                    <label className="text-xs font-bold text-slate-600 block mb-1">Theme Notes & Special Demands</label>
                    <textarea
                      value={enquiryForm.themeNotes}
                      onChange={(e) => setEnquiryForm({ ...enquiryForm, themeNotes: e.target.value })}
                      rows={3}
                      className="w-full bg-neutral-50 p-3 rounded-none border border-neutral-200 text-sm focus:bg-white focus:ring-1 focus:ring-gold focus:outline-none"
                      placeholder="Specify your wedding lawn name or any special elements needed."
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    disabled={submittingEnquiry}
                    className="w-full bg-gold hover:bg-gold-hover text-white font-outfit font-bold uppercase tracking-wider py-4 rounded-none transition-all shadow-md text-sm cursor-pointer disabled:opacity-50"
                  >
                    {submittingEnquiry ? "Transmitting Reservation details..." : "Submit Enquiry & Secure Date"}
                  </button>

                </form>

                {/* COLUMN 2: LIVE BOOKING REGISTRY STREAM (lg:col-span-5) */}
                <div className="lg:col-span-5 space-y-6">
                  
                  <div className="bg-slate-950 text-white p-6 border border-gold/15 shadow-md text-left">
                    <h4 className="text-base font-outfit font-bold text-gold flex items-center gap-2 mb-3">
                      <Sparkles className="w-4 h-4 text-gold" />
                      Live Jalgaon Booking Stream
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed mb-4">
                      Active enquiries being processed by Afternoon Wala. We serve major residential pockets, wedding halls, and corporate areas in Jalgaon City.
                    </p>

                    {loadingEnquiries ? (
                      <div className="text-xs text-slate-400 text-center py-6">Connecting to registry server...</div>
                    ) : (
                      <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1">
                        {submittedEnquiries.map((enq) => (
                          <div key={enq.id} className="bg-slate-900 p-4 border border-slate-800 text-xs flex flex-col justify-between">
                            <div className="flex justify-between items-start gap-2">
                              <div>
                                <span className="font-bold text-white block text-sm">{enq.name}</span>
                                <span className="text-[10px] text-zinc-400 block flex items-center gap-1 mt-0.5">
                                  <MapPin className="w-3 h-3 text-gold" /> Jalgaon City Event
                                </span>
                              </div>
                              <span className="bg-gold/10 text-gold text-[9px] font-mono uppercase font-bold px-2 py-0.5 rounded-none border border-gold/20">
                                {enq.eventType}
                              </span>
                            </div>

                            <div className="mt-3 grid grid-cols-2 gap-2 text-[10px] text-zinc-300 border-t border-slate-800 pt-2.5">
                              <div>
                                <span className="text-zinc-500 block">Event Date:</span>
                                <strong className="text-white">{enq.eventDate}</strong>
                              </div>
                              <div>
                                <span className="text-zinc-500 block">Est. Budget:</span>
                                <strong className="text-gold">{enq.estimatedBudget}</strong>
                              </div>
                            </div>

                            {enq.balloonColors && enq.balloonColors.length > 0 && (
                              <div className="mt-2 text-[10px]">
                                <span className="text-zinc-500 font-bold">Colors mapped:</span>
                                <span className="text-zinc-400 font-semibold ml-1">{enq.balloonColors.join(", ")}</span>
                              </div>
                            )}

                            {enq.lowFogRequired && (
                              <div className="mt-2 text-[9px] inline-flex items-center gap-1.5 text-gold font-medium bg-gold/10 p-1.5 rounded-none border border-gold/20">
                                <Cloud className="w-3.5 h-3.5" /> Magical low-fog effect booked
                              </div>
                            )}

                            <div className="text-[8px] text-right text-zinc-500 mt-2 font-mono">
                              Subm. at {new Date(enq.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                </div>

              </div>

            </div>
          )}

        </div>
      </main>

      {/* FOOTER */}
      <footer className="bg-slate-950 text-neutral-300 border-t border-gold/15 py-12 text-left">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            
            <div className="md:col-span-2 space-y-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-gold" />
                <span className="text-xl font-serif font-bold text-white tracking-tight">
                  Afternoon <span className="text-gold font-outfit italic">Wala</span>
                </span>
              </div>
              <p className="text-sm text-neutral-400 max-w-sm">
                Luxury Event Decorators in Jalgaon City. Specialize in designing breathtaking floral & pastel organic balloon stage creations, dry-ice fog, and premium event styling coordinates.
              </p>
            </div>

            <div className="space-y-3">
              <h5 className="text-white font-outfit font-bold text-sm uppercase tracking-wider">Quality Policies</h5>
              <ul className="space-y-2 text-xs text-neutral-400">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-gold" /> Tidy cabling cover policy
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-gold" /> Double-stuffed pastel latex only
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-gold" /> Safe dry-ice low fog policy
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-gold" /> On-site supervisor present
                </li>
              </ul>
            </div>

            <div className="space-y-3">
              <h5 className="text-white font-outfit font-bold text-sm uppercase tracking-wider">Inquiry Quick Desk</h5>
              <p className="text-xs text-neutral-400 leading-relaxed">
                abhalerao855@gmail.com <br />
                Jalgaon City, Maharashtra, India
              </p>
              <div className="pt-2 flex items-center gap-2 text-gold text-xs font-bold leading-none">
                <Phone className="w-4 h-4 shrink-0" />
                <span>+91 94222 17878</span>
              </div>
            </div>

          </div>

          <div className="mt-8 pt-8 border-t border-slate-900 text-center text-xs text-neutral-500 flex flex-col sm:flex-row justify-between items-center gap-4">
            <p>© 2026 Afternoon Wala. All rights reserved. Registered Indian Hospitality Provider.</p>
            <p className="font-mono text-[10px]">Powered by Gemini-3.5-Flash Staging Intelligence</p>
          </div>
        </div>
      </footer>

      {/* POPUP ENQUIRY SUCCESS CELEBRATION MODAL */}
      {enquirySuccessModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white p-6 sm:p-8 rounded-none max-w-lg w-full shadow-2xl border border-gold/15 flex flex-col items-center text-center space-y-4">
            
            <div className="bg-gold/10 p-3.5 rounded-none border border-gold/20">
              <Sparkles className="w-8 h-8 text-gold animate-bounce" />
            </div>

            <h3 className="text-2xl font-serif font-bold text-slate-900">Your Celebration Is Secured!</h3>
            <p className="text-sm text-slate-600 max-w-sm font-outfit">
              We've successfully registered your enquiry under ID: <strong className="font-mono text-xs">{registeredEnquiryId}</strong>.
            </p>

            <div className="bg-warm-beige/30 p-4 border border-gold/10 w-full text-left text-xs space-y-2.5">
              <div className="font-bold text-slate-900 border-b border-slate-100 pb-1.5 uppercase tracking-wider text-[10px]">WHAT WE DO NOW:</div>
              <div className="flex gap-2 text-slate-700">
                <span className="text-gold font-bold">1.</span>
                <span>Verify venue permission rules for low-fog dry-ice machines in Jalgaon.</span>
              </div>
              <div className="flex gap-2 text-slate-700">
                <span className="text-gold font-bold">2.</span>
                <span>Send you custom color mockup samples via WhatsApp matching your palette.</span>
              </div>
              <div className="flex gap-2 text-slate-700">
                <span className="text-gold font-bold">3.</span>
                <span>Verify decorator availability slot on your chosen event date.</span>
              </div>
            </div>

            <button
              onClick={() => {
                setEnquirySuccessModal(false);
                setActiveTab("showcase");
              }}
              className="bg-slate-950 hover:bg-slate-900 text-white font-outfit font-bold uppercase tracking-wider text-xs px-6 py-4 rounded-none transition-all w-full cursor-pointer"
            >
              Back to Gallery & Packages
            </button>

          </div>
        </div>
      )}

    </div>
  );
}
